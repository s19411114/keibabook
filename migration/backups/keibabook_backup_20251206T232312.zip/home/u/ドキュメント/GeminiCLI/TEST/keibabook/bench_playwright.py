import time
from playwright.sync_api import sync_playwright
import os

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        # browser.process is the subprocess; we print pid for measurement
        pid = None
        try:
            pid = browser.process.pid
        except Exception:
            pid = None
        print(f"PID:{pid}")
        context = browser.new_context()
        page = context.new_page()
        page.goto('about:blank')
        print('Started chromium, sleeping 8s for measurements...')
        # keep browser open briefly so we can sample memory usage
        time.sleep(8)
        browser.close()

if __name__ == '__main__':
    main()
