---
Title: Implementation Plan: <short-title>
Author: <name>
Date: <YYYY-MM-DD>
Status: draft
Tags: plan, implementation, milestone
---

# 実装計画: <短いタイトル>

## 目的
（この実装の目的）

## 成果物
（期待されるアウトプット・ファイルや機能）

## スコープ
（含む/含まない 範囲）

## スケジュール / マイルストーン
- M1: 日付 — 説明
- M2: 日付 — 説明

## タスク一覧（Responsible / Status / Due）
- [ ] Task: 担当者 — Status: todo/in-progress/done — Due: YYYY-MM-DD

## リスクと回避策

## 検証と受け入れ条件

## 関連資料/チケット
