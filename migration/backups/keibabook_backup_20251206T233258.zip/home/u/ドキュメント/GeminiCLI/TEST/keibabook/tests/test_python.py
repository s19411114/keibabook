#!/usr/bin/env python
print("Hello VS Code Python!")
import sys
print(f"Python version: {sys.version}")
print(f"Executable: {sys.executable}")