#!/usr/bin/env bash
# Safe cleanup of known temporary/debug files used during dev/benchmark
set -euo pipefail

# Files to remove (relative to project root or absolute):
files=(
  "/tmp/bench_mntc.sh"
  "/tmp/bench_venv.sh"
  "/tmp/bench_out.txt"
  "/tmp/bench_py_pid.txt"
  "/tmp/playwright_test.py"
  "/tmp/pp_out.txt"
  "/tmp/pp_pid"
)

echo "Cleaning temporary files (dry-run by default)..."
DRY_RUN=true
if [ "${1:-}" = "--force" ]; then
  DRY_RUN=false
fi

for f in "${files[@]}"; do
  if [ -e "$f" ]; then
    if $DRY_RUN; then
      echo "Would remove: $f"
    else
      echo "Removing: $f"
      rm -f "$f"
    fi
  fi
done

echo "Project-level debug files (relative to project root):"
proj_files=(
  "debug_files/debug_pedigree_test.html"
  "debug_files/debug_pedigree.html"
  "debug_files/debug_*"
  "bench_playwright.py"
)
for f in "${proj_files[@]}"; do
  if [ -e "$f" ]; then
    if $DRY_RUN; then
      echo "Would remove: $f"
    else
      echo "Removing: $f"
      rm -f "$f"
    fi
  fi
done

echo "Done. Use --force to actually delete files."
