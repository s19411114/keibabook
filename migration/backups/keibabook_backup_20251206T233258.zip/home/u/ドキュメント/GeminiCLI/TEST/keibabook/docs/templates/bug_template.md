---
Title: Bug: <短い概要>
Reporter: <報告者>
Date: <YYYY-MM-DD>
Status: open
Severity: <high|medium|low>
---

# 再現手順
1. 
2. 

# 期待される挙動

# 実際の挙動

# ログ/スクリーンショット

# 関連ファイル/環境
- OS: 
- Python: 
- その他: 

# 対処/暫定回避策
